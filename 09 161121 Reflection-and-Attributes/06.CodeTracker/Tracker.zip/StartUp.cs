﻿namespace CodeTracker
{
    [Author("Anakin")]
    public class StartUp
    {
        [Author("DartVayder")]
        static void Main(string[] args)
        {
            Tracker tracker = new Tracker();
            tracker.PrintMethodsByAuthor();
        }
    }
}