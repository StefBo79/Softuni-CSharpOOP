﻿using System;

namespace AuthorProblem
{
    [Author("Anakin")]
    public class StartUp
    {
        [Author("DartVaider")]
        static void Main(string[] args)
        {
           
        }
    }
}
