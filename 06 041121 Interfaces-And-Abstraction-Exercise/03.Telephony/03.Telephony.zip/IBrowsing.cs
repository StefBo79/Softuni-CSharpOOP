﻿namespace Telephony
{
    public interface IBrowsing
    {
        string Browse(string url);
    }
}