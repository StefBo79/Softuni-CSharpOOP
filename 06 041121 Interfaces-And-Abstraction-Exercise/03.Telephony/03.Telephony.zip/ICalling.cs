﻿namespace Telephony
{
    public interface ICalling
    {
        string Call(string number);
    }
}