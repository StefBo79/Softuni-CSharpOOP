﻿namespace MilitaryElite
{
    public interface ISpy
    {
        int CodeNumber { get; }
    }
}