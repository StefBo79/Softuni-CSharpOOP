﻿namespace CollectionHierarchy
{
    public interface IMyList
    {
        int Used { get; }
    }
}