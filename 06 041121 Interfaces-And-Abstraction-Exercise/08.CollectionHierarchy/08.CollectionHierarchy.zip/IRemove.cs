﻿namespace CollectionHierarchy
{
    public interface IRemove
    {
        string Remove();
    }
}