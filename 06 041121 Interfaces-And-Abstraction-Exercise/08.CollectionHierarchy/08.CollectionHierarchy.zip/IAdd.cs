﻿namespace CollectionHierarchy
{
    public interface IAdd
    {
        int Add(string item);
    }
}