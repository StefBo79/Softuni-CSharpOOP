﻿namespace BirthdayCelebrations
{
    public interface IPetName : IBirthable
    {
        string Name { get; }
    }
}